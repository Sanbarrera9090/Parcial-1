package entities;

public class Student {
    private int code;
    private String name;
    private String lastName;
    private String email;

}
