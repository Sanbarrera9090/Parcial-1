package entities;

public class Course {
    private String shortName;
    private int credits;
}
