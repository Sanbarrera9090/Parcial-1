package entities;

import java.time.LocalDate;

public class Log {
    /**
     * Atributos de la clase
     */
    private LocalDate date;
    private String advanceDescription;
    private int advancePercentage;
}
